import React from 'react'

const page = () => {
  return (
    <div>
      /seller-faq
    </div>
  )
}

export default page
