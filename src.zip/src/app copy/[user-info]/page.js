import React from 'react'

const page = () => {
  return (
    <div>
      /[user-info]

      user-info = cart, wishlist, myOrder, myAccount
    </div>
  )
}

export default page
