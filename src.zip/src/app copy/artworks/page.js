import React from 'react'

const page = () => {
  return (
    <>
      /artworks


      show all artworks including paintings, drawings etc.
    </>
  )
}

export default page
