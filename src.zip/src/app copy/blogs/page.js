import React from 'react'

const page = () => {
  return (
    <>
      /blogs
    </>
  )
}

export default page
