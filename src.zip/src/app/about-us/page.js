import AboutUS from "../../components/aboutus/index";
import React from "react";

const page = () => {
    
  return (
    <>
      <AboutUS />
    </>
  );
};

export default page;