import { NextResponse } from "next/server";
import crypto from "crypto";
import qs from "qs";

export async function POST(req) {
  try {
    const res = await req.text();
    const parsedBody = qs.parse(res);
    const { razorpay_order_id, razorpay_payment_id, razorpay_signature } = parsedBody

    const body = razorpay_order_id + "|" + razorpay_payment_id;

    const expectedSignature = crypto
      .createHmac("sha256", process.env.NEXT_PUBLIC_RAZORPAY_KEY_SECRET)
      .update(body.toString())
      .digest("hex");

    const isAuthentic = expectedSignature === razorpay_signature;

    if (isAuthentic) {
      // Database operations come here
      // const url = new URL(
      //   `/paymentsuccess/${razorpay_payment_id}`,
      //   req.nextUrl.origin
      // );
      const url ='';
      return NextResponse.redirect(url);
    } else {
      return NextResponse.json({ success: false }, { status: 400 });
    }
  } catch (e) {
    console.log("Error start ", e, "Error ends");
  }
}