import ProductCategory from "../../../components/productCategory/index";
// Return a list of `params` to populate the [slug] dynamic segment
export async function generateStaticParams() {
  const fetchData = await fetch(
    "https://lab2.invoidea.in/rayart/public/api/category-list"
  ).then((res) => res.json());

  const categoryData = fetchData.categories || [];

  return categoryData.map((cat) => ({
    slug: cat.slug,
  }));
}

const page = ({ params }) => {
  return <ProductCategory slug={params.slug} />;
};

export default page;
