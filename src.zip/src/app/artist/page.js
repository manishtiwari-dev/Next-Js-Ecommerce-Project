import Artist from "../../components/artist/index";
import React from "react";

const page = () => {
  return (
    <>
      <Artist />
    </>
  );
};
export default page;
