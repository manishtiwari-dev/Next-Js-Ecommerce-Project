import Checkout from '../../components/checkout/Checkout'
import React from 'react'

const page = () => {
  return (
    <>
      <Checkout/>
    </>
  )
}

export default page
