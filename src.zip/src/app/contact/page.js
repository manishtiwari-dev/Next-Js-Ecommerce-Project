import Contact from "../../components/contact/Contact";
import React from "react";

const page = () => {
  return (
    <>
      <Contact />
    </>
  );
};

export default page;
