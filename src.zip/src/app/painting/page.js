import Painting from "../../components/productCategory/index";
import React from "react";

const page = () => {
  return (
    <>
      <Painting />
    </>
  );
};

export default page;
