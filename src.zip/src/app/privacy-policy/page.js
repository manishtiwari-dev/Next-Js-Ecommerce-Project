import PrivacyPolicy from "../../components/privacyPolicy/index";
import React from "react";

const page = () => {
  return (
    <>
      <PrivacyPolicy />
    </>
  );
};

export default page;