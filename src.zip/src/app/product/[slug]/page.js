import ProductDetails from "../../../components/products/DetailPage";
// Return a list of `params` to populate the [slug] dynamic segment
export async function generateStaticParams() {
  const fetchData = await fetch('https://lab2.invoidea.in/rayart/public/api/product').then((res) => res.json())
 
  const productsdata = fetchData.products.data || []; // Assuming the array of posts is nested under a key 'data'

  // console.log(postdata); // Check the value of posts

  return productsdata.map((post) => ({
    slug: post.slug,
  }))
}  
// Multiple versions of this page will be statically generated
// using the `params` returned by `generateStaticParams`
// export default async function Page({ params }) {
//   console.log(params);

//   const response = await fetch(
//       `https://lab2.invoidea.in/rayart/public/api/product/${params.slug}`
//     );
  
//     const product = await response.json();
  
//     // console.log(product.product.slug);
//   return (
//       <>
//         {/* <ProductDetails slug={slug} /> */}
//         <h1>Slug details : {params.slug}</h1>
//       </>
//     );
// }


const page = ({ params }) => {
    return (
         <ProductDetails slug={params.slug} /> 
    )
}

export default page