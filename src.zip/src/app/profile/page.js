import Profile from '../../components/profile/index'
import React from 'react'

const page = () => {
  return (
    <>
      <Profile/>
    </>
  )
}

export default page
