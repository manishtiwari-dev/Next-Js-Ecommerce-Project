import Shop from '../../components/shop/Shop'
import React from 'react'

const page = () => {
  return (
    <>
      <Shop/>
    </>
  )
}

export default page
