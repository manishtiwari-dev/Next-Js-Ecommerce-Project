import TermsAndCondition from "../../components/termsAndCondition/index";
import React from "react";

const page = () => {
  return (
    <>
      <TermsAndCondition />
    </>
  );
};

export default page;