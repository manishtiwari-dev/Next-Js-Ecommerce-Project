import React from 'react'
import BillingDetails from './BillingDetails'

const Checkout = () => {
    return (
        <>
            <div className="container-fluid py-5">
                <div className="container py-5">
                    <BillingDetails />                    
                </div>
            </div>
        </>
    )
}

export default Checkout
