"use client";
import React, { useState } from "react";
import { useForm } from "react-hook-form";
import { ErrorMessage } from "@hookform/error-message";
import { toast } from "react-toastify";

const Contact = () => {
  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm();


 

  const onSubmit = async (formData) => {
    const saveFormData = formData;
     console.log(saveFormData); 
  //  e.preventDefault();
    // You can perform form validation here if needed
    try {
      // Make an API call or perform any necessary actions with the form data
      const response = await fetch("/api/submitForm", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(saveFormData),
      });
      if (response.ok) {
        toast.success("Thank You For Submit details");
      } else {
        // Handle errors, e.g., show an error message
        toast.error("Form submission failed");
      }
    } catch (error) {
      toast.error("Error submitting form:", error);
    }
  };

  return (
    <>
      <div className="contact-wrapper form-information">
        <div className="container-fluid">
          <div className="row">
            <div className="col-md-7 ps-0 pr-3">
              <div className="image">
                <img src="img/contact-img.png" alt="" />
              </div>
            </div>
            <div className="col-md-5">
              <div className="form-wrap">
                <div className="contact-form">
                  <h6>We’d love to here from you!</h6>
                  <h3>Contact</h3>
                  <form onSubmit={handleSubmit(onSubmit)}>
                    <div className="input-wrap">
                      <input
                        type="text"
                        className="form-control"
                        id="firstname"
                        placeholder="First Name"
                        {...register("fname", {
                          required: "please enter a first name",
                        })}
                      />
                      <div>
                        <span>
                          <ErrorMessage errors={errors} name="fname" />
                        </span>
                      </div>

                      <input
                        type="text"
                        className="form-control"
                        id="lastname"
                        placeholder="Last Name"
                        {...register("lname", {
                          required: "please enter a last name",
                        })}
                      />
                      <span>
                        <ErrorMessage errors={errors} name="lname" />
                      </span>
                    </div>
                    <div className="input-wrap">
                      <input
                        type="email"
                        className="form-control"
                        id="email"
                        placeholder="E-mail"
                        {...register("email", {
                          required: "please enter a email",
                        })}
                      />
                    
                        <span>
                          <ErrorMessage errors={errors} name="email" />
                        </span>
                      
                    </div>
                    <div className="input-wrap">
                      <input
                        type="phone"
                        className="form-control"
                        id="phone"
                        placeholder="Phone Number"
                        {...register("phone", {
                          required: "please enter a phone number",
                        })}
                      />
                        <span>
                          <ErrorMessage errors={errors} name="phone" />
                        </span>
                    </div>
                    <div className="input-wrap">
                      <input
                        type="text"
                        className="form-control"
                        id="subject"
                        placeholder="Subject"
                        {...register("subject", {
                          required: "please enter a subject",
                        })}
                      />
                         <span>
                          <ErrorMessage errors={errors} name="subject" />
                        </span>
                    </div>
                    <div className="input-wrap">
                      <textarea
                        name="message"
                        className="form-control"
                        id="message"
                        placeholder="Leave a Message"
                        rows="10"
                        {...register("message")}
                      ></textarea>
                    </div>

                    <button type="submit" className="btn btn-primary">
                      Submit
                    </button>
                  </form>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default Contact;
