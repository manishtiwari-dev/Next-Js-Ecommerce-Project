"use client";
import React, { useState, useEffect } from "react";
import { fetchHomeData } from "../../redux/reducer/homePageReducer";
import { ImageBaseUrl } from "../../config";
import { useDispatch, useSelector } from "react-redux";
import Link from "next/link";
import SkeletonLatestCollections from "../../helpers/SkeletonLatestCollections";

const LatestCollection = () => {
  const dispatch = useDispatch();
  const { homePageData, loading, dataFetched } = useSelector(
    (state) => state.Home
  );
  const latestProducts = homePageData.latestProducts;

  useEffect(() => {
    if (!dataFetched) {
      dispatch(fetchHomeData());
    }
  }, [dispatch, dataFetched]);
  return (
    <>
      {latestProducts ? (
        <section className="Latest-collections desktop-lastest-collections">
          <div className="container-fluid">
            <div className="row">
              <h3>Latest Collections</h3>

              {latestProducts && latestProducts.length > 0 ? (
                latestProducts.map((item, index) => (
                  <div className="column">
                    {/* <a href="#"> */}
                    <div className="imasonry-items">
                      <div className="image">
                        <img
                          src={`${ImageBaseUrl}${item.thumb_image}`}
                          alt=""
                        />
                      </div>
                      <div className="content">
                        <div className="col-left">
                          <h5>
                            {item.short_description.length > 50
                              ? `${item.short_description.slice(0, 50)}...`
                              : item.short_description}
                          </h5>
                          <span>{item.name}</span>
                          <h6>70X20 In</h6>
                        </div>
                        <div className="col-right">
                          <div className="icon">
                            <svg
                              xmlns="http://www.w3.org/2000/svg"
                              width="20"
                              height="20"
                              viewBox="0 0 20 20"
                              fill="none"
                            >
                              <path
                                d="M14.1121 14.1683C12.258 15.792 10.3616 16.847 10.1025 16.987C9.84341 16.847 7.94699 15.792 6.09293 14.1683C4.13723 12.4556 2.40653 10.2643 2.40635 7.96042C2.40763 6.90777 2.82637 5.89858 3.57072 5.15423C4.31506 4.40988 5.32425 3.99115 6.37691 3.98987C7.72562 3.98997 8.87417 4.56674 9.58271 5.51041L10.1025 6.2027L10.6223 5.51041C11.3308 4.56674 12.4794 3.98997 13.8281 3.98987C14.8808 3.99115 15.8899 4.40988 16.6343 5.15423C17.3787 5.89867 17.7975 6.908 17.7987 7.96079C17.7983 10.2645 16.0677 12.4557 14.1121 14.1683Z"
                                stroke="#6A5B9C"
                                stroke-width="1.3"
                              ></path>
                            </svg>
                          </div>
                          <span className="price">₹{item.price}</span>
                        </div>
                      </div>
                      <Link href={`/product/${item.slug}`}>
                        <button type="button" className="btn btn-link viewBtn">
                          View
                        </button>
                      </Link>

                      {/* <Link href={{pathname: "product/[slug]",query: { slug: item.slug },}}>
                    <button
                      type="button"
                      className="btn btn-link viewBtn">
                      View
                    </button></Link> */}

                      <button type="button" className="btn btn-link addBtn">
                        Add to cart
                      </button>
                      <hr />
                    </div>
                  </div>
                ))
              ) : (
                <p>Loading...</p>
              )}
              {/* <div className="column">
              <a href="#">
                <div className="imasonry-items">
                  <div className="image">
                    <img src="/img/item18.png" alt="" />
                  </div>
                  <div className="content">
                    <div className="col-left">
                      <h5>Majestic Deer</h5>
                      <span>Digital Art</span>
                      <h6>303X202 In</h6>
                    </div>
                    <div className="col-right">
                      <div className="icon">
                        <svg
                          xmlns="http://www.w3.org/2000/svg"
                          width="20"
                          height="20"
                          viewBox="0 0 20 20"
                          fill="none"
                        >
                          <path
                            d="M14.1121 14.1683C12.258 15.792 10.3616 16.847 10.1025 16.987C9.84341 16.847 7.94699 15.792 6.09293 14.1683C4.13723 12.4556 2.40653 10.2643 2.40635 7.96042C2.40763 6.90777 2.82637 5.89858 3.57072 5.15423C4.31506 4.40988 5.32425 3.99115 6.37691 3.98987C7.72562 3.98997 8.87417 4.56674 9.58271 5.51041L10.1025 6.2027L10.6223 5.51041C11.3308 4.56674 12.4794 3.98997 13.8281 3.98987C14.8808 3.99115 15.8899 4.40988 16.6343 5.15423C17.3787 5.89867 17.7975 6.908 17.7987 7.96079C17.7983 10.2645 16.0677 12.4557 14.1121 14.1683Z"
                            stroke="#6A5B9C"
                            stroke-width="1.3"
                          ></path>
                        </svg>
                      </div>
                      <span className="price">₹61,000</span>
                    </div>
                  </div>
                  <button type="button" className="btn btn-link viewBtn">
                    View
                  </button>
                  <button type="button" className="btn btn-link addBtn">
                    Add to cart
                  </button>
                  <hr />
                </div>
              </a>

              <a href="#">
                <div className="imasonry-items">
                  <div className="image">
                    <img src="/img/item22.png" alt="" />
                  </div>
                  <div className="content">
                    <div className="col-left">
                      <h5>Cute Litter fox</h5>
                      <span>Painting</span>
                      <h6>304X368 In</h6>
                    </div>
                    <div className="col-right">
                      <div className="icon">
                        <svg
                          xmlns="http://www.w3.org/2000/svg"
                          width="20"
                          height="20"
                          viewBox="0 0 20 20"
                          fill="none"
                        >
                          <path
                            d="M14.1121 14.1683C12.258 15.792 10.3616 16.847 10.1025 16.987C9.84341 16.847 7.94699 15.792 6.09293 14.1683C4.13723 12.4556 2.40653 10.2643 2.40635 7.96042C2.40763 6.90777 2.82637 5.89858 3.57072 5.15423C4.31506 4.40988 5.32425 3.99115 6.37691 3.98987C7.72562 3.98997 8.87417 4.56674 9.58271 5.51041L10.1025 6.2027L10.6223 5.51041C11.3308 4.56674 12.4794 3.98997 13.8281 3.98987C14.8808 3.99115 15.8899 4.40988 16.6343 5.15423C17.3787 5.89867 17.7975 6.908 17.7987 7.96079C17.7983 10.2645 16.0677 12.4557 14.1121 14.1683Z"
                            stroke="#6A5B9C"
                            stroke-width="1.3"
                          ></path>
                        </svg>
                      </div>
                      <span className="price">₹61,000</span>
                    </div>
                  </div>
                  <button type="button" className="btn btn-link viewBtn">
                    View
                  </button>
                  <button type="button" className="btn btn-link addBtn">
                    Add to cart
                  </button>
                </div>
              </a>
            </div>
            <div className="column">
              <a href="#">
                <div className="imasonry-items">
                  <div className="image">
                    <img src="/img/item19.png" alt="" />
                  </div>
                  <div className="content">
                    <div className="col-left">
                      <h5>Women Power</h5>
                      <span>Painting</span>
                      <h6>304X382 In</h6>
                    </div>
                    <div className="col-right">
                      <div className="icon">
                        <svg
                          xmlns="http://www.w3.org/2000/svg"
                          width="20"
                          height="20"
                          viewBox="0 0 20 20"
                          fill="none"
                        >
                          <path
                            d="M14.1121 14.1683C12.258 15.792 10.3616 16.847 10.1025 16.987C9.84341 16.847 7.94699 15.792 6.09293 14.1683C4.13723 12.4556 2.40653 10.2643 2.40635 7.96042C2.40763 6.90777 2.82637 5.89858 3.57072 5.15423C4.31506 4.40988 5.32425 3.99115 6.37691 3.98987C7.72562 3.98997 8.87417 4.56674 9.58271 5.51041L10.1025 6.2027L10.6223 5.51041C11.3308 4.56674 12.4794 3.98997 13.8281 3.98987C14.8808 3.99115 15.8899 4.40988 16.6343 5.15423C17.3787 5.89867 17.7975 6.908 17.7987 7.96079C17.7983 10.2645 16.0677 12.4557 14.1121 14.1683Z"
                            stroke="#6A5B9C"
                            stroke-width="1.3"
                          ></path>
                        </svg>
                      </div>
                      <span className="price">₹61,000</span>
                    </div>
                  </div>
                  <button type="button" className="btn btn-link viewBtn">
                    View
                  </button>
                  <button type="button" className="btn btn-link addBtn">
                    Add to cart
                  </button>
                  <hr />
                </div>
              </a>
              <a href="#">
                <div className="imasonry-items">
                  <div className="image">
                    <img src="/img/item23.png" alt="" />
                  </div>
                  <div className="content">
                    <div className="col-left">
                      <h5>Statue Adiyogi</h5>
                      <span>Painting</span>
                      <h6>304X289 In</h6>
                    </div>
                    <div className="col-right">
                      <div className="icon">
                        <svg
                          xmlns="http://www.w3.org/2000/svg"
                          width="20"
                          height="20"
                          viewBox="0 0 20 20"
                          fill="none"
                        >
                          <path
                            d="M14.1121 14.1683C12.258 15.792 10.3616 16.847 10.1025 16.987C9.84341 16.847 7.94699 15.792 6.09293 14.1683C4.13723 12.4556 2.40653 10.2643 2.40635 7.96042C2.40763 6.90777 2.82637 5.89858 3.57072 5.15423C4.31506 4.40988 5.32425 3.99115 6.37691 3.98987C7.72562 3.98997 8.87417 4.56674 9.58271 5.51041L10.1025 6.2027L10.6223 5.51041C11.3308 4.56674 12.4794 3.98997 13.8281 3.98987C14.8808 3.99115 15.8899 4.40988 16.6343 5.15423C17.3787 5.89867 17.7975 6.908 17.7987 7.96079C17.7983 10.2645 16.0677 12.4557 14.1121 14.1683Z"
                            stroke="#6A5B9C"
                            stroke-width="1.3"
                          ></path>
                        </svg>
                      </div>
                      <span className="price">₹61,000</span>
                    </div>
                  </div>
                  <button type="button" className="btn btn-link viewBtn">
                    View
                  </button>
                  <button type="button" className="btn btn-link addBtn">
                    Add to cart
                  </button>
                </div>
              </a>
            </div>
            <div className="column">
              <a href="#">
                <div className="imasonry-items">
                  <div className="image">
                    <img src="img/item20.png" alt="" />
                  </div>
                  <div className="content">
                    <div className="col-left">
                      <h5>Colored Roof</h5>
                      <span>Abstract</span>
                      <h6>303X354 In</h6>
                    </div>
                    <div className="col-right">
                      <div className="icon">
                        <svg
                          xmlns="http://www.w3.org/2000/svg"
                          width="20"
                          height="20"
                          viewBox="0 0 20 20"
                          fill="none"
                        >
                          <path
                            d="M14.1121 14.1683C12.258 15.792 10.3616 16.847 10.1025 16.987C9.84341 16.847 7.94699 15.792 6.09293 14.1683C4.13723 12.4556 2.40653 10.2643 2.40635 7.96042C2.40763 6.90777 2.82637 5.89858 3.57072 5.15423C4.31506 4.40988 5.32425 3.99115 6.37691 3.98987C7.72562 3.98997 8.87417 4.56674 9.58271 5.51041L10.1025 6.2027L10.6223 5.51041C11.3308 4.56674 12.4794 3.98997 13.8281 3.98987C14.8808 3.99115 15.8899 4.40988 16.6343 5.15423C17.3787 5.89867 17.7975 6.908 17.7987 7.96079C17.7983 10.2645 16.0677 12.4557 14.1121 14.1683Z"
                            stroke="#6A5B9C"
                            stroke-width="1.3"
                          ></path>
                        </svg>
                      </div>
                      <span className="price">₹61,000</span>
                    </div>
                  </div>
                  <button type="button" className="btn btn-link viewBtn">
                    View
                  </button>
                  <button type="button" className="btn btn-link addBtn">
                    Add to cart
                  </button>
                  <hr />
                </div>
              </a>
              <a href="#">
                <div className="imasonry-items">
                  <div className="image">
                    <img src="/img/item24.png" alt="" />
                  </div>
                  <div className="content">
                    <div className="col-left">
                      <h5>Flower Vase</h5>
                      <span>Painting</span>
                      <h6>70X20 In</h6>
                    </div>
                    <div className="col-right">
                      <div className="icon">
                        <svg
                          xmlns="http://www.w3.org/2000/svg"
                          width="20"
                          height="20"
                          viewBox="0 0 20 20"
                          fill="none"
                        >
                          <path
                            d="M14.1121 14.1683C12.258 15.792 10.3616 16.847 10.1025 16.987C9.84341 16.847 7.94699 15.792 6.09293 14.1683C4.13723 12.4556 2.40653 10.2643 2.40635 7.96042C2.40763 6.90777 2.82637 5.89858 3.57072 5.15423C4.31506 4.40988 5.32425 3.99115 6.37691 3.98987C7.72562 3.98997 8.87417 4.56674 9.58271 5.51041L10.1025 6.2027L10.6223 5.51041C11.3308 4.56674 12.4794 3.98997 13.8281 3.98987C14.8808 3.99115 15.8899 4.40988 16.6343 5.15423C17.3787 5.89867 17.7975 6.908 17.7987 7.96079C17.7983 10.2645 16.0677 12.4557 14.1121 14.1683Z"
                            stroke="#6A5B9C"
                            stroke-width="1.3"
                          ></path>
                        </svg>
                      </div>
                      <span className="price">₹61,000</span>
                    </div>
                  </div>
                  <button type="button" className="btn btn-link viewBtn">
                    View
                  </button>
                  <button type="button" className="btn btn-link addBtn">
                    Add to cart
                  </button>
                </div>
              </a>
            </div> */}
            </div>
          </div>
        </section>
      ) : (
        <SkeletonLatestCollections />
      )}

      {/* mobile latest collections */}
      <section className="Latest-collections mobile-lastest-collections">
        <div className="container-fluid">
          <div className="row">
            <h3>Latest Collections</h3>
            <div className="column">
              <a href="#">
                <div className="imasonry-items">
                  <div className="image">
                    <img src="img/item17.png" alt="" />
                  </div>
                  <div className="content">
                    <div className="col-left">
                      <h5>The life view</h5>
                      <span>Painting</span>
                      <h6>70X20 In</h6>
                    </div>
                    <div className="col-right">
                      <div className="icon">
                        <svg
                          xmlns="http://www.w3.org/2000/svg"
                          width="20"
                          height="20"
                          viewBox="0 0 20 20"
                          fill="none"
                        >
                          <path
                            d="M14.1121 14.1683C12.258 15.792 10.3616 16.847 10.1025 16.987C9.84341 16.847 7.94699 15.792 6.09293 14.1683C4.13723 12.4556 2.40653 10.2643 2.40635 7.96042C2.40763 6.90777 2.82637 5.89858 3.57072 5.15423C4.31506 4.40988 5.32425 3.99115 6.37691 3.98987C7.72562 3.98997 8.87417 4.56674 9.58271 5.51041L10.1025 6.2027L10.6223 5.51041C11.3308 4.56674 12.4794 3.98997 13.8281 3.98987C14.8808 3.99115 15.8899 4.40988 16.6343 5.15423C17.3787 5.89867 17.7975 6.908 17.7987 7.96079C17.7983 10.2645 16.0677 12.4557 14.1121 14.1683Z"
                            stroke="#6A5B9C"
                            stroke-width="1.3"
                          ></path>
                        </svg>
                      </div>
                      <span className="price">₹61,000</span>
                    </div>
                  </div>
                  <button type="button" className="btn btn-link viewBtn">
                    View
                  </button>
                  <button type="button" className="btn btn-link addBtn">
                    Add to cart
                  </button>
                  <hr />
                </div>
              </a>
              <a href="#">
                <div className="imasonry-items">
                  <div className="image">
                    <img src="img/item18.png" alt="" />
                  </div>
                  <div className="content">
                    <div className="col-left">
                      <h5>Majestic Deer</h5>
                      <span>Digital Art</span>
                      <h6>303X202 In</h6>
                    </div>
                    <div className="col-right">
                      <div className="icon">
                        <svg
                          xmlns="http://www.w3.org/2000/svg"
                          width="20"
                          height="20"
                          viewBox="0 0 20 20"
                          fill="none"
                        >
                          <path
                            d="M14.1121 14.1683C12.258 15.792 10.3616 16.847 10.1025 16.987C9.84341 16.847 7.94699 15.792 6.09293 14.1683C4.13723 12.4556 2.40653 10.2643 2.40635 7.96042C2.40763 6.90777 2.82637 5.89858 3.57072 5.15423C4.31506 4.40988 5.32425 3.99115 6.37691 3.98987C7.72562 3.98997 8.87417 4.56674 9.58271 5.51041L10.1025 6.2027L10.6223 5.51041C11.3308 4.56674 12.4794 3.98997 13.8281 3.98987C14.8808 3.99115 15.8899 4.40988 16.6343 5.15423C17.3787 5.89867 17.7975 6.908 17.7987 7.96079C17.7983 10.2645 16.0677 12.4557 14.1121 14.1683Z"
                            stroke="#6A5B9C"
                            stroke-width="1.3"
                          ></path>
                        </svg>
                      </div>
                      <span className="price">₹61,000</span>
                    </div>
                  </div>
                  <button type="button" className="btn btn-link viewBtn">
                    View
                  </button>
                  <button type="button" className="btn btn-link addBtn">
                    Add to cart
                  </button>
                  <hr />
                </div>
              </a>
            </div>
            <div className="column">
              <a href="#">
                <div className="imasonry-items">
                  <div className="image">
                    <img src="img/item20.png" alt="" />
                  </div>
                  <div className="content">
                    <div className="col-left">
                      <h5>Colored Roof</h5>
                      <span>Abstract</span>
                      <h6>303X354 In</h6>
                    </div>
                    <div className="col-right">
                      <div className="icon">
                        <svg
                          xmlns="http://www.w3.org/2000/svg"
                          width="20"
                          height="20"
                          viewBox="0 0 20 20"
                          fill="none"
                        >
                          <path
                            d="M14.1121 14.1683C12.258 15.792 10.3616 16.847 10.1025 16.987C9.84341 16.847 7.94699 15.792 6.09293 14.1683C4.13723 12.4556 2.40653 10.2643 2.40635 7.96042C2.40763 6.90777 2.82637 5.89858 3.57072 5.15423C4.31506 4.40988 5.32425 3.99115 6.37691 3.98987C7.72562 3.98997 8.87417 4.56674 9.58271 5.51041L10.1025 6.2027L10.6223 5.51041C11.3308 4.56674 12.4794 3.98997 13.8281 3.98987C14.8808 3.99115 15.8899 4.40988 16.6343 5.15423C17.3787 5.89867 17.7975 6.908 17.7987 7.96079C17.7983 10.2645 16.0677 12.4557 14.1121 14.1683Z"
                            stroke="#6A5B9C"
                            stroke-width="1.3"
                          ></path>
                        </svg>
                      </div>
                      <span className="price">₹61,000</span>
                    </div>
                  </div>
                  <button type="button" className="btn btn-link viewBtn">
                    View
                  </button>
                  <button type="button" className="btn btn-link addBtn">
                    Add to cart
                  </button>
                  <hr />
                </div>
              </a>

              <a href="#">
                <div className="imasonry-items">
                  <div className="image">
                    <img src="img/item19.png" alt="" />
                  </div>
                  <div className="content">
                    <div className="col-left">
                      <h5>Women Power</h5>
                      <span>Painting</span>
                      <h6>304X382 In</h6>
                    </div>
                    <div className="col-right">
                      <div className="icon">
                        <svg
                          xmlns="http://www.w3.org/2000/svg"
                          width="20"
                          height="20"
                          viewBox="0 0 20 20"
                          fill="none"
                        >
                          <path
                            d="M14.1121 14.1683C12.258 15.792 10.3616 16.847 10.1025 16.987C9.84341 16.847 7.94699 15.792 6.09293 14.1683C4.13723 12.4556 2.40653 10.2643 2.40635 7.96042C2.40763 6.90777 2.82637 5.89858 3.57072 5.15423C4.31506 4.40988 5.32425 3.99115 6.37691 3.98987C7.72562 3.98997 8.87417 4.56674 9.58271 5.51041L10.1025 6.2027L10.6223 5.51041C11.3308 4.56674 12.4794 3.98997 13.8281 3.98987C14.8808 3.99115 15.8899 4.40988 16.6343 5.15423C17.3787 5.89867 17.7975 6.908 17.7987 7.96079C17.7983 10.2645 16.0677 12.4557 14.1121 14.1683Z"
                            stroke="#6A5B9C"
                            stroke-width="1.3"
                          ></path>
                        </svg>
                      </div>
                      <span className="price">₹61,000</span>
                    </div>
                  </div>
                  <button type="button" className="btn btn-link viewBtn">
                    View
                  </button>
                  <button type="button" className="btn btn-link addBtn">
                    Add to cart
                  </button>
                  <hr />
                </div>
              </a>
            </div>

            <div className="btn-viewAll">
              <button type="button" className="btn btn-link artBtn">
                View All
              </button>
            </div>
          </div>
        </div>
      </section>
    </>
  );
};
export default LatestCollection;
