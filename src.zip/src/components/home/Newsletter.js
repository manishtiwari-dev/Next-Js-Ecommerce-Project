"use client";
import React from "react";

const Newsletter = () => {
  return (
    <>
      <section className="newsletter-banner">
        <div className="container-fluid">
          <div className="row">
            <div className="heading">
              <h3>Looking For Art Beauty?</h3>
            </div>
            <div className="newsletter">
              <div className="box">
                <form>
                  <p>
                    Don’t miss out on the latest art. Ray Artwala bring the
                    masterpieces to you!
                  </p>
                  <input
                    type="email"
                    className="form-control"
                    id="email"
                    placeholder="Enter Email"
                    name="email"
                  />
                  <button type="submit" className="btn btn-primary">
                    Subscribe
                  </button>
                </form>
              </div>
            </div>
          </div>
        </div>
      </section>
    </>
  );
};
export default Newsletter;
