// src/pages/product/[slug]/page.js
"use client";
import React, { useEffect, useState } from "react";
import { fetchHomeData } from "../../redux/reducer/homePageReducer";
import { ImageBaseUrl } from "../../config";
import { useDispatch, useSelector } from "react-redux";
import Loading from '../../helpers/Loader'

const DetailPage = ({ slug }) => {
  console.log(slug);
  const dispatch = useDispatch();
  const { homePageData, dataFetched } = useSelector((state) => state.Home);

  useEffect(() => {
    if (!dataFetched) {
      dispatch(fetchHomeData());
    }
  }, [dispatch, dataFetched, homePageData]);

  const [product, setProduct] = useState(null);
  const [loading, setLoading] = useState(true); // Add loading state
  useEffect(() => {
    const fetchProduct = async () => {
      try {
        const response = await fetch(
          `https://lab2.invoidea.in/rayart/public/api/product/${slug}`
        );
        const data = await response.json();
        setProduct(data.product);
        setLoading(false);
      } catch (error) {
        console.error("Error fetching product details:", error);
        setLoading(false);
      }
    };

    fetchProduct();
  }, [slug]);


  return (
    <>
      <div className="container-fluid py-5 mt-5">
        <div className="container py-5">
          {loading ? (
           
             <Loading/>
          ) : product ? (
            <div className="row g-4 mb-5">
              <h1 className="text-center">{product.name}</h1>
              <div className="col-lg-4">
                <div className="image">
                  <img
                    src={`${ImageBaseUrl}${product.thumb_image ?? ""}`}
                    alt=""
                  />
                </div>
              </div>
              <div className="col-lg-6">
                <div
                  dangerouslySetInnerHTML={{ __html: product.long_description }}
                ></div>
              </div>
            </div>
          ) : (
              <div className="justify-content-center">
                      <Loading/>
                      </div>
          )}
        </div>
      </div>
    </>
  );
};

export default DetailPage;
