"use client";
import React, { useEffect } from "react";

const index = () => {
  return (
    <>
      <div className="profile-wrapper spaceingtop">
        <div className="container-fluid">
          <div className="row">
            <h3>Profile</h3>
            <div className="tabber-wrapper">
              <div className="tabber">
                <ul className="tabber-list">
                  <li>
                    <a href="#tab1">Profile Details</a>
                  </li>
                  <li>
                    <a href="#tab2">Billing Details</a>
                  </li>
                </ul>
              </div>
              <div className="tabber-content-wrapper">
                <div className="tabber-content" id="tab1">
                  <div className="row">
                    <div className="col-md-4">
                      <div className="profile-wrap">
                        <img src="img/user.png" alt="" />
                        <h5>User Name</h5>
                        <span>Change Profile Picture</span>
                      </div>
                    </div>
                    <div className="col-md-8">
                      <div className="form-wrap">
                        <form action="#">
                          <div className="input-wrap">
                            <input
                              type="name"
                              className="form-control"
                              id="name"
                              placeholder="User Name"
                              name="name"
                            />
                            <input
                              type="email"
                              className="form-control"
                              id="email"
                              placeholder="Username@gmail.com"
                              name="email"
                            />
                          </div>
                          <div className="input-wrap">
                            <input
                              type="country"
                              className="form-control"
                              id="country"
                              placeholder="India"
                              name="country"
                            />
                            <input
                              type="number"
                              className="form-control"
                              id="number"
                              placeholder="9876543210"
                              name="number"
                            />
                          </div>
                          <div className="input-wrap">
                            <textarea
                              name="address"
                              placeholder="Address"
                              className="form-control"
                              id="address"
                              rows="5"
                            ></textarea>
                          </div>

                          <button type="submit" className="btn btn-primary">
                            Update Profile
                          </button>
                        </form>
                      </div>
                    </div>
                  </div>
                </div>
                <div className="tabber-content" id="tab2">
                  <div className="row">
                    <div className="col-md-4">
                      <div className="profile-wrap">
                        <img src="img/user.png" alt="" />
                        <h5>User Name</h5>
                        <span>Change Profile Picture</span>
                      </div>
                    </div>
                    <div className="col-md-8">
                      <div className="form-wrap">
                        <form action="#">
                          <div className="input-wrap mb-3">
                            <input
                              type="name"
                              className="form-control mt-2"
                              id="name"
                              placeholder="Card Holder Name"
                              name="name"
                            />
                            <input
                              type="number"
                              className="form-control mt-2"
                              id="cardNum"
                              placeholder="Card Number"
                              name="number"
                            />
                          </div>
                          <div className="input-wrap mb-3">
                            <input
                              type="name"
                              className="form-control"
                              id="bankname"
                              placeholder="Bank Name"
                              name="name"
                            />
                            <input
                              type="code"
                              className="form-control"
                              id="code"
                              placeholder="IFSC Code"
                              name="code"
                            />
                          </div>

                          <button type="submit" className="btn btn-primary">
                            Change Account
                          </button>
                        </form>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};
export default index;
