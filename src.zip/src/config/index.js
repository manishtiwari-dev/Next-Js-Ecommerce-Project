export const domainUrl = "https://lab2.invoidea.in";
export const BaseUrl = `${domainUrl}/rayart/public/api`;

export const ImageBaseUrl = `${domainUrl}/rayart/public/`;

export const AuthUrl = `${domainUrl}/auth`;
export const CartUrl = `${domainUrl}/cart`;
export const OrdersUrl = `${domainUrl}/orders`;
export const ProductsUrl = `${domainUrl}/product`;
export const WishListUrl = `${domainUrl}/wishlist`;

//home
export const HomeUrl = `${BaseUrl}/website-setup`;
export const SearchProductUrl = `${BaseUrl}/search-product`;
export const ProductDetailsUrl = `${BaseUrl}/product/`;
export const ArtistListUrl = `${BaseUrl}/sellers/`;
export const ProductUrl = `${BaseUrl}/product`;

export const AboutUsUrl = `${BaseUrl}/about-us`;
export const PrivacyPolicyUrl = `${BaseUrl}/privacy-policy`;
export const TermsAndConditionUrl = `${BaseUrl}/terms-and-conditions`;



