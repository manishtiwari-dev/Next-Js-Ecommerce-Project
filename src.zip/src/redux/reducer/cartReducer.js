import { createSlice } from "@reduxjs/toolkit";
import { toast } from "react-toastify";

const initialState = {
  loading: false,
  cart: [],
  discount: 0,
  total_items: 0,
  total_price: 0,
  shippingInfo: {
    address: "",
    city: "",
    state: "",
    country: "",
    pinCode: "",
  },
};

export const cartSlice = createSlice({
  name: "Cart",
  initialState,
  reducers: {
    addToCart: (state, action) => {
      state.loading = true;
      let { product, user } = action.payload;
      let existingProduct = state.cart.find(
        (curItem) => curItem.id === product.id
      );
      if (!existingProduct) {
        // const formData = {
        //     productID: product.id,
        //     userID: user.id,
        // }
        // const addItem = AddToCart(formData);
        state.cart.push(product);
        toast.success(`${product.title} is added to cart`);
        localStorage.setItem("cart", JSON.stringify(state.cart));
      } else {
        toast.warning(`${product.title} is already in cart`);
      }
      state.loading = false;
    },
    removeFromCart: (state, action) => {
      state.loading = true;
      let id = action.payload;

      state.cart = state.cart.filter((item) => {
        return item.id !== id;
      });

      toast.success(`Item is removed from cart`);

      localStorage.setItem("cart", JSON.stringify(state.cart));

      state.loading = false;
    },
    setCartItems: (state, action) => {
      state.cart = action.payload;
    },
    setTotalItems: (state, action) => {
      state.total_items = state.cart.length;
    },
    setTotalPrice: (state, action) => {
      const totalPrice = state.cart.reduce(
        (total, item) => total + parseFloat(item.price.replace("$", "")),
        0
      );
      state.total_price = parseFloat(totalPrice.toFixed(2));
    },
    setDiscountApplied: (state, action) => {
      state.discount = action.payload;
    },
    saveShippingInfo: (state, action) => {
      state.shippingInfo = action.payload;
    },
    clearCart: (state, action) => {
      state.cart = [];
      state.total_items = 0;
      state.total_price = 0;
      localStorage.removeItem("cart");
    },
  },
});

export const {
  addToCart,
  removeFromCart,
  setCartItems,
  setTotalItems,
  setTotalPrice,
  setDiscountApplied,
  saveShippingInfo,
  clearCart,
} = cartSlice.actions;

export const CartReducer = cartSlice.reducer;
