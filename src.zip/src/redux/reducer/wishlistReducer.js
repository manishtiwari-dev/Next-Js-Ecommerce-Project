import { getSingleProduct } from "../../services/products";
import {
  AddToWishList,
  GetAllWishListItems,
  RemoveItemFromWishList,
} from "../../services/wishlist";
import { createSlice } from "@reduxjs/toolkit";

const initialState = {
  loading: false,
  wishlist: [],
};

export const wishlistSlice = createSlice({
  name: "WishList",
  initialState,
  reducers: {
    addToWishlist: (state, action) => {
      state.loading = true;
      let { product, user } = action.payload;

      let existingProduct = state.wishlist.find(
        (curItem) => curItem.id === product.id
      );
      if (existingProduct) {
        toast.warning("Product already is in wishlist");
      } else {
        const formData = {
          productID: product.id,
          userID: user.id,
        };
        const addItem = AddToWishList(formData);
        state.wishlist.push(product);
      }
      state.loading = false;
    },
    removeFromWishList: (state, action) => {
      state.loading = true;
      let { product, user } = action.payload;

      const formData = {
        productID: product.id,
        userID: user.id,
      };

      const removeItem = RemoveItemFromWishList(formData);

      state.wishlist = state.filter((item) => {
        return item.id !== product.id;
      });

      state.loading = false;
    },
    setWishList: (state, action) => {
      state.loading = true;
      const id = action.payload; // this id is of the user
      try {
        const getItems = GetAllWishListItems(id);
        getItems.map((productId) => {
          const product = getSingleProduct(productId);
          state.wishlist.push(product);
        });
      } catch (e) {
        console.log(e);
      }
      state.loading = false;
    },
  },
});

export const { addToWishlist, removeFromWishList, setWishList } =
  wishlistSlice.actions;

export const WishListReducer = wishlistSlice.reducer;
