'use client'

import {configureStore} from '@reduxjs/toolkit';
import { UserReducer } from './reducer/userReducer';
import { CartReducer } from './reducer/cartReducer';
import { OrderReducer } from './reducer/orderReducer';
import { ProductReducer } from './reducer/productReducer';
import { WishListReducer } from './reducer/wishlistReducer';
import { homePageReducer } from './reducer/homePageReducer';

export const store = configureStore({
    reducer: {
        User : UserReducer,
        Cart: CartReducer,
        Order: OrderReducer,
        Product: ProductReducer,
        WishList: WishListReducer,
        Home: homePageReducer
    },
})