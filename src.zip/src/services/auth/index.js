import { AuthUrl } from "../../config";

import axios from "axios";

export const CollectorRegister = async (formData) => {
  try {
    const res = await axios(`${AuthUrl}/register-collector`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: formData,
    });
    return res.data;
  } catch (error) {
    console.log("error in registering collector => ", error);
  }
};

export const SellerRegister = async (formData) => {
  try {
    const res = await axios(`${AuthUrl}/register-seller`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: formData,
    });
    return res.data;
  } catch (error) {
    console.log("error in registering seller => ", error);
  }
};

export const Login = async (formData) => {
  try {
    const res = await axios(`${AuthUrl}/login`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: formData,
    });
    return res.data;
  } catch (error) {
    console.log("error in login => ", error);
  }
};
