import axios from "axios";
import { CartUrl } from "../../config";

export const AddToCart = async (formData) => {
  // const formData = { productID, userID}
  try {
    const res = await axios(`${CartUrl}/add-to-cart`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        // 'Authorization': `Bearer ${Cookies.get('token')}`
      },
      body: formData,
    });
    return res.data;
  } catch (error) {
    console.log("Error in Add product to cart (service) =>", error);
  }
};

export const GetAllCartItems = async (id) => {
  // id is user id
  try {
    const res = await axios(`${CartUrl}/get-cart-items?id=${id}`, {
      method: "GET",
    });
    const data = await res.json();
    return data;
  } catch (error) {
    console.log(
      "Error in getting all cart Item for specific User (service) =>",
      error
    );
  }
};

export const RemoveItemFromCart = async (formData) => {
  // const formData = { productID, userID}
  try {
    const res = await axios(`${Cart}/remove-from-cart`, {
      method: "DELETE",
      data: formData,
    });

    const data = await res.json();
    return data;
  } catch (error) {
    console.log("Error in deleting cart item (service) =>", error);
  }
};
