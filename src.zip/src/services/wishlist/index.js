import axios from "axios";
import { WishListUrl } from "../../config";

export const AddToWishList = async (formData) => {
  // const formData = { productID, userID}
  try {
    const res = await axios(`${WishListUrl}/add-to-wishist`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        // 'Authorization': `Bearer ${Cookies.get('token')}`
      },
      body: formData,
    });
    return res.data;
  } catch (error) {
    console.log("Error in Add product to wishlist =>", error);
  }
};

export const GetAllWishListItems = async (id) => {
  // id is user id
  try {
    const res = await axios(`${WishListUrl}/get-wishlist-items?id=${id}`, {
      method: "GET",
    });
    const data = await res.json();
    return data;
  } catch (error) {
    console.log(
      "Error in getting all wishlist Item for specific User =>",
      error
    );
  }
};

export const RemoveItemFromWishList = async (formData) => {
  // const formData = { productID, userID}
  try {
    const res = await axios(`${WishListUrl}/remove-from-wishlist`, {
      method: "DELETE",
      data: formData,
    });

    return res.data;
  } catch (error) {
    console.log("Error in deleting wishlist item =>", error);
  }
};
